pub static MAGIC_FLAG : [u8;2] = [0x37, 0x37];

pub fn makeword(a : u8, b : u8) -> u16{
	((a as u16) << 8) | b as u16
}
/*
pub fn splitword(a : u16) -> (u8 , u8) {
    return ((a >> 8) as u8  , a as u8)
}*/